import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AllCategoryHome.css'; // Import the above CSS styles here

const AllCategory = () => {
  const [category, setCategory] = useState([]);
  const [message, setMessage] = useState('');

  useEffect(() => {
    const fetchCategory = async () => {
      try {
        const response = await axios.get('http://localhost:5000/getCategoryHome');
        const data = response.data;

        if (data.status === 'ok') {
          setCategory(data.data); // Set data to 'category' state
        } else {
          setMessage(data.message);
        }
      } catch (error) {
        setMessage('An error occurred: ' + error.message);
      }
    };

    fetchCategory();
  }, []);

  const handleview = (categoryId) => {
    window.location.href = `/CategoryView/${categoryId}`;
  };
  return (
    <div className="container2">
      {message && <p>{message}</p>}
      <div className="">
        {category.map((cat, index) => (
          <div key={index} className="homecategoryside mb-2">
            <div className="sidecategoryHome" onClick={() => handleview(cat._id)}> 
              {cat.image ? (
                <img 
                  src={`http://localhost:5000/${cat.image.replace('\\', '/')}`} 
                  className="card-img-top categoryimageside"  
                  alt={cat.name}
                />
              ) : (
                <img 
                  src="path_to_default_image.jpg" 
                  className="card-img-top categoryimage2" 
                  alt="default"
                />
              )}
              <div className="card-body">
               
                <h5 className="card-title categorynameSide ellipsis ">{cat.name}</h5>
                
                {/* Add more category details or buttons here */}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AllCategory;
